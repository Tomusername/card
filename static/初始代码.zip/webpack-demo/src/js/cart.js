require(['./common.js'], function (common) {
    common.initCart();
    $(function () {
        console.log("this is jquery cart")
    })
})